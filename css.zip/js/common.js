$(function () {
  //SP版ヘッダーモーダルメニュー
  var gwFixedContent = $(".gw-wrapper");
  var gwScrollPosi = 0;
  $("#js__gw-sp-hnav").on("click", function () {
    if (!$("body").hasClass("is-gw-hnav-open")) {
      gwScrollPosi = $(window).scrollTop();
      $("body").addClass("is-gw-hnav-open");
      gwFixedContent.css({
        position: "fixed",
        top: -1 * gwScrollPosi,
      });
    } else {
      $("body").removeClass("is-gw-hnav-open");
      gwFixedContent.attr("style", "");
      $("html, body").prop({ scrollTop: gwScrollPosi });
    }
  });

  var gwWinWidth = window.innerWidth;
  // if (gwWinWidth <= 767) {
  //   //SP版ヘッダーメニュー　子ページのアコーディオン表示
  //   $(".js__gw-header-child-nav").on("click", function () {
  //     var gwNavParent = $(this).find(".gw-header-nav__parent-item");
  //     var gwNavChild = $(this).find(".gw-header-nav__child");

  //     if (!gwNavParent.hasClass("is-open")) {
  //       gwNavParent.addClass("is-open");
  //     } else {
  //       gwNavParent.removeClass("is-open");
  //     }

  //     gwNavChild.stop().slideToggle(200);
  //     return false; //リンクの無効化
  //   });

  //   $(".gw-header-nav__child-top").on("click", function (e) {
  //     e.stopPropagation();
  //   });

  //   $(".gw-header-nav__child-item").on("click", function (e) {
  //     e.stopPropagation();
  //   });

  //   //SP版フッターメニュー　子ページのアコーディオン表示
  //   $(".js__gw-footer-child-nav").on("click", function () {
  //     var gwNavParent = $(this).children(".gw-footer-nav__parent-item");
  //     var gwNavChild = $(this).children(".gw-footer-nav__child");

  //     if (!gwNavParent.hasClass("is-open")) {
  //       gwNavParent.addClass("is-open");
  //     } else {
  //       gwNavParent.removeClass("is-open");
  //     }

  //     gwNavChild.stop().slideToggle(200);
  //     return false; //リンクの無効化
  //   });

  //   $(".gw-footer-nav__child-item").on("click", function (e) {
  //     e.stopPropagation();
  //   });
  // }

  // if (gwWinWidth >= 768) {
  //   //PC版ヘッダーメニュー　子ページのホバー表示
  //   $(".js__gw-header-child-nav").hover(function () {
  //     $(this).find(".gw-header-nav__child").stop().slideToggle(200);

  //     var gwNavParent = $(this).find(".gw-header-nav__parent-item");
  //     var gwNavChildList = $(this).find(".gw-header-nav__child-inner");

  //     if (!gwNavParent.hasClass("is-open")) {
  //       gwNavParent.addClass("is-open");
  //       gwNavChildList.addClass("is-open");
  //       $("body").addClass("is-open");
  //       gwNavChildList.removeClass("is-hide");
  //     } else {
  //       gwNavParent.removeClass("is-open");
  //       gwNavChildList.removeClass("is-open");
  //       $("body").removeClass("is-open");
  //       gwNavChildList.addClass("is-hide");
  //     }
  //   });
  // }

  //ページトップの表示
  var gwPageTop = $(".gw-footer-pagetop");
  if (gwPageTop[0]) {
    $(window).scroll(function () {
      if ($(this).scrollTop() > 500) {
        gwPageTop.fadeIn(500).css("display", "block");
      } else {
        gwPageTop.fadeOut(500);
      }
    });
  }

  //アンカーリンクのスムーズスクロール
  $('a[href^="#"]').click(function () {
    var gwScrollSpeed = 500;
    var gwScrollHref = $(this).attr("href");
    var gwScrollTarget = $(
      gwScrollHref == "#" || gwScrollHref == "" ? "html" : gwScrollHref
    );
    var gwScrollPosi = gwScrollTarget.offset().top;
    $("html, body").animate(
      { scrollTop: gwScrollPosi },
      gwScrollSpeed,
      "swing"
    );
    return false;
  });

  //トップページ　ニュースのタブ切り替え
  var gwNewsTab = $(".gw-top-news__panel-tab-item");
  var gwNewspanel = $(".gw-top-news__panel");
  $(".js__gw-news-tab").on("click", function () {
    var $gwNewsPanelIndex = $(this).index();
    gwNewsTab.removeClass("is-active");
    gwNewspanel.removeClass("is-active");
    $(this).addClass("is-active");
    gwNewspanel.eq($gwNewsPanelIndex).addClass("is-active");
  });

  //トップページ　採用情報の画像ランダム表示
  var gwRecruitPhotoArr = [];
  var gwRecruitPhoto = $(".gw-top-recruit__photo");
  $(".gw-top-recruit__photo li").each(function () {
    gwRecruitPhotoArr.push($(this).html());
  });
  gwRecruitPhotoArr.sort(function () {
    return Math.random() - Math.random();
  });
  gwRecruitPhoto.empty();
  for (i = 0; i < gwRecruitPhotoArr.length; i++) {
    gwRecruitPhoto.append("<li>" + gwRecruitPhotoArr[i] + "</li>");
  }

  //トップページ　遅延表示 （ヒーローイメージとニュース）
  setTimeout(function () {
    setTimeout(function () {
      $(".gw-top-hero__headline-en.js__gw-delay").addClass("is-delay");
    }, 250);
    setTimeout(function () {
      $(".gw-top-hero__headline-main.js__gw-delay").addClass("is-delay");
    }, 500);
    setTimeout(function () {
      $(".gw-top-hero__headline-sub.js__gw-delay").addClass("is-delay");
    }, 750);
    setTimeout(function () {
      $(".gw-top-hero__img.js__gw-delay").addClass("is-delay");
    }, 1000);
  }, 250);

  //トップページ　遅延表示
  if (
    $(".js__gw-delay-strengths")[0] ||
    $(".js__gw-delay-about")[0] ||
    $(".js__gw-delay-company")[0] ||   
    $(".js__gw-delay-service")[0] ||
    $(".js__gw-delay-techblog")[0] ||
    $(".js__gw-delay-news")[0] ||
    $(".js__gw-delay-recruit")[0]
  ) {
    $(window).scroll(function () {
      var gwTopScroll = $(window).scrollTop();
      var gwTopWinHeight = $(window).height();

      //PanGuの強み
      if (
        gwTopScroll >
        $(".js__gw-delay-strengths").offset().top - gwTopWinHeight + 300
      ) {
        setTimeout(function () {
          $(".gw-top-strengths").addClass("is-delay");
        }, 250);
        setTimeout(function () {
          $(".gw-top-strengths__ttl").addClass("is-delay");
        }, 500);
        setTimeout(function () {
          $(".gw-top-strengths__pic").addClass("is-delay");
        }, 1000);
      }

      //私たちについて
      if (
        gwTopScroll >
        $(".js__gw-delay-about").offset().top - gwTopWinHeight + 300
      ) {
        setTimeout(function () {
          $(".gw-top-about").addClass("is-delay");
        }, 250);
        setTimeout(function () {
          $(".gw-top-about__box").addClass("is-delay");
        }, 1000);
      }

      //企業情報
      if (
        gwTopScroll >
        $(".js__gw-delay-company").offset().top - gwTopWinHeight + 300
      ) {
        setTimeout(function () {
          $(".gw-top-company").addClass("is-delay");
        }, 250);
        setTimeout(function () {
          $(".gw-top-company .gw-top-company__ttl").addClass("is-delay");
        }, 500);
        setTimeout(function () {
          $(".gw-top-company .gw-top-company__item01").addClass("is-delay");
        }, 750);
        setTimeout(function () {
          $(".gw-top-company .gw-top-company__item02").addClass("is-delay");
        }, 1000);
        setTimeout(function () {
          $(".gw-top-company .gw-top-company__item03").addClass("is-delay");
        }, 1250);
        setTimeout(function () {
          $(".gw-top-company .gw-top-company__item04").addClass("is-delay");
        }, 1500);
      }

      //サービス
      if (
        gwTopScroll >
        $(".js__gw-delay-service").offset().top - gwTopWinHeight + 300
      ) {
        setTimeout(function () {
          $(".gw-top-service").addClass("is-delay");

          setTimeout(function () {
            $(".gw-top-service .gw-section-info").addClass("is-delay");
          }, 250);
          setTimeout(function () {
            $(".gw-top-service__list").addClass("is-delay");
          }, 500);

          for (let i = 1; i <= 6; i++) {
            setTimeout(function () {
              $(`.gw-top-service__list-item:nth-of-type(${i})`).addClass(
                "is-delay"
              );
            }, 500 + 250 * i);
          }
        }, 250);
      }

      //情報ブログ
      if (
        gwTopScroll >
        $(".js__gw-delay-techblog").offset().top - gwTopWinHeight + 300
      ) {
        setTimeout(function () {
          $(".gw-top-techblog").addClass("is-delay");
        }, 250);
        setTimeout(function () {
          $(".gw-top-techblog .gw-section-info__ttl").addClass("is-delay");
        }, 500);
        setTimeout(function () {
          $(".gw-top-techblog .gw-section-info__desc").addClass("is-delay");
        }, 750);
        setTimeout(function () {
          $(".gw-top-techblog .salesforce-section").addClass("is-delay");
        }, 1000);
        setTimeout(function () {
          $(".gw-top-techblog .heroku-section").addClass("is-delay");
        }, 1250);
      }

       //ニュース
      if (
        gwTopScroll >
        $(".js__gw-delay-news").offset().top - gwTopWinHeight + 300
      ) {
        setTimeout(function () {
          $(".gw-top-news .gw-section-info").addClass("is-delay");
        }, 250);
        setTimeout(function () {
          $(".gw-top-news__panel-wrapper").addClass("is-delay");
        }, 1000);
      }

      //採用情報
      if (
        gwTopScroll >
        $(".js__gw-delay-recruit").offset().top - gwTopWinHeight + 300
      ) {
        setTimeout(function () {
          $(".gw-top-recruit .gw-section-info__ttl").addClass("is-delay");

          setTimeout(function () {
            $(".gw-top-recruit__img-box").addClass("is-delay");
          }, 250);
          setTimeout(function () {
            $(".gw-top-recruit .gw-section-info__desc").addClass("is-delay");
          }, 1000);
          setTimeout(function () {
            $(".gw-top-recruit .gw-btn").addClass("is-delay");
          }, 1250);
        }, 250);
      }
    });
  }

  //input[type="file"]のファイル名表示
  $('input[type="file"]').on("change", function () {
    var gwFileProp = $(this).prop("files")[0];
    var gwFile = $(this).parents(".gw-form__file");
    gwFile.addClass("is-hasfile");
    gwFile.find(".gw-form__file-name").html(gwFileProp.name);
  });

  //textareaのりサイズ（IE用）
  if ($(".wpcf7-textarea")[0]) {
    $(".wpcf7-textarea").funcResizeBox({});
  }

  // トップページ用の要素がある場合、初期表示用にカラのscrollイベントを発火させておく
  if ($(".gw-top")[0]) {
    $(document).trigger("scroll");
  }

  // スクロール時にヘッダーに白の背景色をつける
  $(function () {
    $(window).scroll(() => {
      let scroll = $(this).scrollTop();
      if (scroll > 100) {
        $(".gw-header").addClass("is-scrolled");
      } else {
        $(".gw-header").removeClass("is-scrolled");
      }
    });
  });

  $(function () {
    const nav = document.getElementById("gw-header-nav");
  });
});

// contact-form-7の送信完了後のリダイレクト
document.addEventListener(
  "wpcf7mailsent",
  function (event) {
    location = "/contact-2/thanks/";
  },
  false
);
