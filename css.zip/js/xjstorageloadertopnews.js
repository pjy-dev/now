// JavaScript Document

//========================================================
//
// ■XJStorageLoaderクラス定義
//
//========================================================
(function ($) {

  if (!Array.prototype.indexOf) {
    Array.prototype.indexOf = function (elt /*, from*/ ) {
      var len = this.length;

      var from = Number(arguments[1]) || 0;
      from = (from < 0)
        ? Math.ceil(from)
        : Math.floor(from);
      if (from < 0)
        from += len;

      for (; from < len; from++) {
        if (from in this
          && this[from] === elt)
          return from;
      }
      return -1;
    };
  }

  (function () {

    /*========================================================
     コンストラクタ
    ========================================================*/
    XjStorageLoaderIrTop = function (s) {
      var defaults = {
        domain: '//www.xj-storage.jp',
        company: 'AS82666',
        full: '1',
        icon: '1',
        pdf: '1',
        len: '5',
        documents_all: '',
        documents_Disclosure: '0,5,6,8,9,13,15,24,25,28',
        documents_Fresults: '1,2,3,4,16,17,18,19,20,21',
        documents_Sreport: '1030,1040,1080,1090,1100,1120,1130,1135,1136,1140,1150,1160,1170,1180,1190,1200,1210,1220,1230,1235,1236,1240,1250,1260,1270,1280,1290,1300,1310,1320,1350,1360',
        documents_Ir: '34,90,91,92,93,95,96,97,98,101,102,103,104,110,111,112,113,114,115,116,117,118,119,120,1900,10001',
        documents_Info: '14,200'

      };

      this.settings = $.extend(defaults, s);
      this.fdate;
      this.pdate;
      this.documents;
      this.ary_doc_no;
      this.ary_doc_Disclosure;
      this.ary_doc_Fresults;
      this.ary_doc_Sreport;
      this.ary_doc_Ir;
      this.ary_doc_Info;


      XjStorageLoaderIrTop.prototype.init.call(this);
    };

    /*========================================================
     初期設定
    ========================================================*/
    XjStorageLoaderIrTop.prototype.init = function () {
      $.ajaxSetup({
        scriptCharset: 'utf-8'
      });

      this.ary_doc_Disclosure = this.settings.documents_Disclosure.split(",")
      this.ary_doc_Fresults = this.settings.documents_Fresults.split(",");
      this.ary_doc_Sreport = this.settings.documents_Sreport.split(",");
      this.ary_doc_Ir = this.settings.documents_Ir.split(",");
      this.ary_doc_Info = this.settings.documents_Info.split(",");


      this.settings.documents_all =
        this.settings.documents_Disclosure + ','
        + this.settings.documents_Fresults + ','
        + this.settings.documents_Sreport + ','
        + this.settings.documents_Ir + ','
        + this.settings.documents_Info;


      this.documents = this.settings.documents_all;
      this.ary_doc_no = this.settings.documents_all.split(",");

      this.show();
    };

    /*========================================================
     表示処理
    ========================================================*/
    XjStorageLoaderIrTop.prototype.show = function () {
      var url = this.settings.domain + '/public-list/GetList2.aspx?company=';
      var self = this;
      var is_first = true;

      url += this.settings.company;

      if (this.fdate && this.fdate.length > 0) {
        url += '&fdate=' + this.fdate;
      }

      if (this.pdate && this.pdate.length > 0) {
        url += '&pdate=' + this.pdate;
      }

      if (this.documents && this.documents.length > 0) {
        url += '&doctype=' + this.documents;
      }

      if (self.settings.len && self.settings.len > 0) {
        url += '&len=' + self.settings.len;
      } else if (!(this.pdate && this.pdate.length > 0)
        && !(this.fdate && this.fdate.length > 0)) {
        url += '&len=4';
      } else {
        url += '&len=10000';
      }

      url += '&output=json&callback=?';

      //clipboardData.setData('text',url);

      $.getJSON(url,
        function (data) {
          $('#xj-mainlist').empty();

          var cont = '';

          if (data.items) {

            var j = 0;
            var now_dd = new Date();

            $.each(data.items, function (i, item) {
              // 目的の文書番号でなかったら
              if (-1 == self.ary_doc_no.indexOf(item.disclosureCode)) {
                return true;
              }

              var url = '';
              var size = '';
              var page = '';

              if (item.files) {
                $.each(item.files, function (j, file) {
                  if (file.type == 'PDF-GENERAL') {
                    url = file.url;
                    size = parseInt(file.size);
                    page = file.page;
                  } else if (file.type == 'HTML-GENERAL') {
                    url = file.url;
                  }
                });
              }

              // サイズ設定
              if (size > 0) {

                if (size > 1000000) {
                  size = parseInt(size / 1000000) + 'M';
                } else if (size > 1000) {

                  size = parseInt(size / 1000) + 'K';
                }
              } else {
                size = '－';
              }

              // アイコンファイル設定
              var icon_class = '';
              var icon_alt = '';


              if (-1 != self.ary_doc_Disclosure.indexOf(item.disclosureCode)) {
                icon_class = 'label-discro';
                icon_alt = '適時開示';
              } else if (-1 != self.ary_doc_Fresults.indexOf(item.disclosureCode)) {
                icon_class = 'label-result';
                icon_alt = '決算短信';
              } else if (-1 != self.ary_doc_Sreport.indexOf(item.disclosureCode)) {
                icon_class = 'label-legal';
                icon_alt = '法定開示';
              } else if (-1 != self.ary_doc_Ir.indexOf(item.disclosureCode)) {
                icon_class = 'label-ir';
                icon_alt = 'IR資料';
              } else if (-1 != self.ary_doc_Info.indexOf(item.disclosureCode)) {
                icon_class = 'label-info';
                icon_alt = 'お知らせ';
              }

              // 日付設定
              var date = item.publishDate.split(' ')[0].split('/');
              var dateStr = date[0] + '-' + date[1] + '-' + date[2];
              var date_dd = new Date(parseInt(date[0], 10),
                parseInt(date[1], 10) - 1,
                parseInt(date[2], 10));


              // 画面表示

              cont += '<li>';

              if (url != '') {
                cont += '<a href="' + url + '" target="_blank" class="inner">';
              } else {
                cont += '<span class="inner">';
              }

              cont += '<span class="date">' + dateStr + '</span>';

              cont += '<div class="cat-wrap"><span class="cat ' + icon_class + '">' + icon_alt + '</span></div>';

              cont += '<p>';

              cont += item.title;

              if (url != '' && size != '－') {
                cont += '<span class="icon icon-pdf">（' + size + 'B）</span>';
              } else if (url != '') {
                cont += '<span class="icon icon-blank"></span>';
              }


              // 30日以内だったら
              /*if ( 30 * 86400000 >= now_dd.getTime ( ) - date_dd.getTime ( ) )
              {
              	cont += '<span class="new">NEW!</span>' ;
              }*/

              cont += '</p>';

              if (url != '') {
                cont += '</a>';
              } else {
                cont += '</span>';
              }

              cont += '</li>';
            });
          } else {
            cont += '<li><span class="inner no-date"><p>ただいま掲載すべき事項はございません。</p></span></li>';
          }

          $('#xj-mainlist').append(cont);
        });
    }

  }());

  $(function () {
    var xj_storage_loader = new XjStorageLoaderIrTop();
  });
})(jQuery);
