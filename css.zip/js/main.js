$.fn.scrollEnd = function(callback, timeout) {          
    $(this).scroll(function(){
      var $this = $(this);
      if ($this.data('scrollTimeout')) {
        clearTimeout($this.data('scrollTimeout'));
      }
      $this.data('scrollTimeout', setTimeout(callback,timeout));
    });
};
$(function(){
    if ( window.location.pathname == '/' ){
        var windowWidth = $(window).width();
        $(window).resize(function(){
            
            if ($(window).width() != windowWidth) {
                location.reload();
                windowWidth = $(window).width();
            }
        })
    }
    $('#home #main').vegas({
        delay : 5000,
        color: '#000',
        timer: false,
        transition: 'fade2',
        slides: [
            { src: '' },
            { src: '' },
            { src: '' },
        ],  
    });
    /*
    Spナビゲーション
    */
    var overlay = '<div class="overlay"></div>';
    var triggerClose = '<div class="sp-nav-close"></div>';
    var storedPos;
    $('.sp-nav-btn').on('click', function(){
        
        if($('.sp-nav-close').length == 0){
            storedPos = $(window).scrollTop();
        }

        $('.sp-navigation').addClass('show')
        var topSpacing = $('header').outerHeight();
        if($('body').hasClass('admin-bar')){
            topSpacing += $('#wpadminbar').outerHeight();
            $('header').css('top', $('#wpadminbar').outerHeight()  + 'px');
            $('.sp-navigation').css('top', topSpacing  + 'px');
        } else {
            $('.sp-navigation').css('top', topSpacing  + 'px');
        }
        if($('.sp-nav-close').length == 0){
            $(this).append(triggerClose);
        }
        if($('.overlay').length == 0){
            $('body').append(overlay);
        }
        setTimeout(function(){
            $('html').addClass('nav-open');
        }, 10);
        
        return storedPos
    });
    $(document).on('click', '.overlay, .sp-nav-close', function(){
        var navHeight = $('.sp-navigation').outerHeight() + 'px';
        $('.sp-navigation').css('top', '-' + navHeight);
        $('.sp-nav-close').remove();
        $('.overlay').remove();
        
        
        setTimeout(function(){
            $('html').removeClass('nav-open');
            $(window).scrollTop(storedPos);
        }, 10);
        
        
    })
    $('.sp-navigation > .sp-navigation-inner > ul > li > a').on('click', function(e){
        if($(this).siblings('ul').length){
            e.preventDefault();
            $(this).toggleClass('child-open');
            $(this).siblings('ul').slideToggle();
        }
    })
    /*
    PCナビゲーション用アニメーション
    */
    //固定ヘッダー用に上部スペース追加
    function addHeaderSpace(){
        var headerHeight = $('header').outerHeight();
        $('main').css('padding-top', headerHeight + 'px');
    }
    addHeaderSpace();
    $(window).resize(function(){
        addHeaderSpace();
    })
    //サブメニュー表示時にオーバーレイ表示
    $('.pc-navigation ul li').each(function(){
        if($(this).children('.sub-menu').length){
            $(this).mouseenter(function(){
                $('.sub-menu-overlay').addClass('on');
            });
            $(this).mouseleave(function(){
                $('.sub-menu-overlay').removeClass('on');
            });
        }
    })
    //スクロール開始でヘッダーにクラス付与し、ヘッダーボタン表示の調整
    //スマホ時はリセット
    $(window).on('scroll', function(){
        var scroll = $(this).scrollTop();
        $('header').addClass('scrolling');
        if(window.matchMedia('(min-width: 1000px)').matches){
            if(scroll > 0){
                $('header').addClass('scrolled');
                $('header .pc-btn-set').hide();
            } else {
                $('header').removeClass('scrolled');
                $('header .pc-btn-set').fadeIn();
            }
        } else {
            $('header').removeClass('scrolled');
            $('header .pc-btn-set').hide();
        }
    }); 
    /*
    スクロール開始で固定ボタン表示
    */
    $(window).on('scroll', function(){
        var scroll = $(this).scrollTop();
        if(scroll > 0){
            $('.fixed-content').fadeIn();
        } else {
            $('.fixed-content').fadeOut();
        }  
    });
    //固定ボタンアニメーション
    $('.fixed-content a').mouseenter(function() {
        $(this).addClass('on');
    });
    $('.fixed-content a').mouseleave(function() {
        $(this).removeClass('on');
    });
    $(window).on('scroll', function(){
        $('.fixed-content a').removeClass('on');
    });
    //フッター高さ分の位置を取るよう調整
    $(window).on('scroll', function(){
        var footHeight = $('footer').outerHeight();
        var footerPos = $('footer').offset().top;
        var scroll = $(this).scrollTop();
        var windowHeight = $(window).height();
        var btnBottom1,
            btnBottom2,
            btnBottom3;
        if(window.matchMedia('(min-width: 768px)').matches){
            btnBottom1 = 170;
            btnBottom2 = 110;
            btnBottom3 = 50;
        } else {
            btnBottom1 = 130;
            btnBottom2 = 80;
            btnBottom3 = 30;
        }
        $('.fixed-content a, .fixed-content .pagetop').css('opacity', '0.6');
        // if(scroll + windowHeight > footerPos){ 
        //     var y = footHeight - ($(document).height() - (scroll + windowHeight));
        //     $('.fixed-content > a.contact').css('bottom',  y + btnBottom1 + 'px');
        //     $('.fixed-content > a.download').css('bottom',  y + btnBottom2 + 'px');
        //     $('.fixed-content .pagetop').css('bottom',  y + btnBottom3 + 'px');
        // } else {
        //     $('.fixed-content > a, .fixed-content .pagetop').css('bottom', '');
        // }  
    });
    /*
    スクロールストップ時
    */
    $(window).scrollEnd(function(){
        $('.fixed-content a, .fixed-content .pagetop').css('opacity', '1');
        $('header').removeClass('scrolling');
    }, 500);
    /*
    ページトップボタン
    */
    $('.pagetop').click(function() {
        $('body, html').animate({ scrollTop: 0 }, 500);
       return false;
    });
    /*
    テキストアニメーション
    */
    setTimeout(function(){
        $('#main h2 > span').each(function(i){            
            var contWidth = $(this).outerWidth();
            $(this).css('width', '0');
            $(this).addClass('visible');
            $(this).css('right', contWidth + 'px');

            var $this = $(this),
                $mask = $(this).children('.mask');
            setTimeout(function(){
                $this.animate({
                    right: "0",
                    width: contWidth
                }, 500, function() {
                    $mask.animate({
                        left: contWidth,
                        width: "0"
                    }, 500);
                });
            },100*i);
        })
    },500);
    $(window).on('scroll', function(){
        var scroll = $(this).scrollTop();
        var windowHeight = $(window).height();

        $('#home h3.txt-animation').each(function(i){
            var elPos = $(this).offset().top;
            if(scroll + (windowHeight / 5) * 4 > elPos && !$(this).hasClass('animated')){
                $(this).children('span').each(function(i){
                    var contWidth = Math.ceil($(this).outerWidth() + 20);
                    var pos = $(this).offset().left
                    $(this).css('width', '0px');
                    $(this).addClass('visible');
                    $(this).css('left', '-' + contWidth / 2 + 'px');
        
                    var $this = $(this),
                        $mask = $(this).children('.mask');
                    setTimeout(function(){
                        $this.animate({
                            width: contWidth - 2,
                            left: '0'
                        }, 500, function() {
                            $mask.animate({
                                left: contWidth - 3,
                                width: '0'
                            }, 500, function(){
                                $mask.fadeOut();
                            });
                        });
                    },100*i);
                    
                })
                $(this).addClass('animated');
            }
        })
    })
    /*
    フェードインアニメーション
    */ 
    var space = 10;
    $('.fade-from-bottom').css('top', space + 'px');
    $('.fade-from-left').css('left', '-=' + space + 'px');
    $(window).on('scroll', function(){
        var scroll = $(this).scrollTop();
        var windowHeight = $(window).height();
        $('.fade-from-bottom').each(function(){
            var elPos = $(this).offset().top - space
            if(scroll + (windowHeight / 5) * 4 > elPos && !$(this).hasClass('animated')){
                $(this).animate({
                    opacity: '1',
                    top: '0'
                }, 800);
                $(this).addClass('animated');
            }
        })
        $('.fade-from-left').each(function(){
            var elPos = $(this).offset().top
            if(scroll + (windowHeight / 5) * 4 > elPos && !$(this).hasClass('animated')){
                $(this).animate({
                    opacity: '1',
                    left: '+=10'
                }, 800);
                $(this).addClass('animated');
            }
        })
    })
    if($('.monthly-post').length){
        $('.monthly-post > ul > li> a').on('click', function(e){
            e.preventDefault();
            $(this).toggleClass('active');
            $(this).parent().find('ul').slideToggle();
        })
    }
    //smooth scrolling
    $(document).on('click', 'a.anchor[href^="#"]', function (event) {
        event.preventDefault();
        const space = $('header').outerHeight(); 
        $('html, body').animate({
            scrollTop: $($.attr(this, 'href')).offset().top - space
        }, 500);
    });
    //number countup
    function zeroPadding(num,length){
        return ('0000000000' + num).slice(-length);
    }
    $(window).on('scroll', function(){
        var scroll = $(this).scrollTop();
        var windowHeight = $(window).height();
        $('.count').each(function () {
            var elPos = $(this).offset().top - space;
            if(scroll + (windowHeight / 5) * 4 > elPos && !$(this).hasClass('animated')){
                $(this).prop('Counter',$(this).text()).animate({
                    Counter: $(this).data('counter')
                }, {
                    duration: 1000,
                    easing: 'swing',
                    step: function (now) {
                        $(this).text(Math.ceil(now));
                    }
                });
                $(this).addClass('animated');
            }
        });
        $('.count-month').each(function () {
            var elPos = $(this).offset().top - space;
            if(scroll + (windowHeight / 5) * 4 > elPos && !$(this).hasClass('animated')){
                $(this).prop('Counter',$(this).text()).animate({
                    Counter: $(this).data('counter')
                }, {
                    duration: 1000,
                    easing: 'swing',
                    step: function (now) {
                        $(this).text(zeroPadding(Math.ceil(now),2));
                    }
                });
                $(this).addClass('animated');
            }
        });
        $('.history-cont').each(function(){
            var elPos = $(this).offset().top - space;
            if(scroll + (windowHeight / 5) * 4 > elPos && !$(this).hasClass('animated')){
                var imgCount = $(this).find('img').length;
                $(this).find('img').each(function(index){
                    $(this).delay(index*800).animate({
                        duration: 2000,
                        easing: 'easeInQuad',
                        opacity: '1'
                    });
                })
                $(this).addClass('animated');
            }
        })
    });
    
    //form validation trigger
    $(".form-with-validate").validationEngine('attach',{
        promptPosition: "topLeft", 
        autoPositionUpdate: true, 
        maxErrorsPerField: 1,
        validateNonVisibleFields: true
    });
    $(".form-with-validate").on('submit', function(e){
        if (grecaptcha.getResponse() == ""){
            e.preventDefault();
        } 
    })
    $('#g-recaptcha-input').val('');
    

    
    //read more btn
    if($('.readmore-wrap').length){
        detectReadmoreHeight()
        $(window).resize(function(){
            detectReadmoreHeight()
        })
        $('.readmoreBtn a').on('click', function(e){
            e.preventDefault();
            
            $el = $(this).parent('.readmoreBtn').prev('.readmore-wrap');
            posBottom = $el.offset().top;
            posTop = $el.outerHeight;
            pos = posBottom + posTop
            $el.toggleClass('animated');
            $(this).toggleClass('open');
            if($el.hasClass('animated')){
                $(this).html('閉じる');
                $el.animate({height: $el[0].scrollHeight + 'px'})
            } else {
                $(this).html('続きを読む');
                $el.animate({height: $el.data('content')})
            }
        })
    }

    function detectReadmoreHeight(){
        $('.readmore-wrap').each(function(){
            $(this).attr('data-content', $(this).outerHeight() + 'px');
        })
    }
    
  
  /*
  お問い合わせ確認・完了時の画面スクロール
  */
  var $location_url = location.href;
  var $remove_lastslash = $location_url.replace(/\/$/, '');
  var $split_url = $remove_lastslash.split("/");
  var $end_path = $split_url[$split_url.length - 1];
  if ($end_path == 'check' || $end_path == 'thanks' || $end_path == 'document-thanks') {
    var target_distance = $('.page-content').offset().top;
    $('body, html').animate({ scrollTop: target_distance }, 500);
  }

})
//reset browser default auto scroll on form submit
var elements = document.querySelectorAll('input,select,textarea');
for (var i = elements.length; i--;) {
    elements[i].addEventListener('invalid', function () {
        this.scrollIntoView(false);
    });
}

//recaptcha resize
$(function(){
    function rescaleCaptcha(){
        var width = $('.g-recaptcha').parent().width();
        var scale;
        if (width < 302) {
        scale = width / 302;
        } else{
        scale = 1.0; 
        }

        $('.g-recaptcha').css('transform', 'scale(' + scale + ')');
        $('.g-recaptcha').css('-webkit-transform', 'scale(' + scale + ')');
        $('.g-recaptcha').css('transform-origin', '0 0');
        $('.g-recaptcha').css('-webkit-transform-origin', '0 0');
    }

    rescaleCaptcha();
    $( window ).resize(function() { rescaleCaptcha(); });

});



//recaptcha callback
function recaptcha_callback(){
    $('#g-recaptcha-input').val('1');
    $('#g-recaptcha-input').validationEngine('validate')
}