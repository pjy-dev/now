﻿/*---------------------------------
  eir.js
  last update: 2014/05/22
-----------------------------------*/

var eirCode = '3936';
var message = '<div><img src="https://www.globalway.co.jp/wp-content/uploads/2016/04/eir.gif" width="460" height="52"></div>';
